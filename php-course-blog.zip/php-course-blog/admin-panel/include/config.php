<?php

define("DNS", "mysql:host=localhost;port=3307;dbname=php_course_blog;charset=utf8mb4");

define("DB_USER", "root");

define("DB_PASS", "");