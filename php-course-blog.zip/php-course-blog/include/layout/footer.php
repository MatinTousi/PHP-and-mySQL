<?php


?>


<footer class="text-center pt-4 my-md-5 pt-md-5 border-top">
    <div class="row flex-column">
        <div>
            <p class="">
                کلیه حقوق محتوا این سایت متعلق به وب سایت Matin Tousi
                میباشد
            </p>
        </div>
        <div>
            <a href="#"><i
                    class="bi bi-telegram fs-3 text-secondary ms-2"></i></a>
            <a href="#"><i
                    class="bi bi-whatsapp fs-3 text-secondary ms-2"></i></a>
            <a href="#"><i class="bi bi-instagram fs-3 text-secondary"></i></a>
        </div>
    </div>
</footer>
</div>
<script
    src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm"
    crossorigin="anonymous"></script>
</body>

</html>